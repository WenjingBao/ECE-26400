#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "list.h"

/** INTERFACE FUNCTIONS **/

PathLL * buildPaths() {
	PathLL * retval = malloc(sizeof(PathLL));
	retval->head = NULL;
	return retval;
}

void freePaths(PathLL * p) {
  if (p -> head -> next != NULL){
    PathNode * a = p -> head;
    PathNode * b;
    while(a != NULL){
      b = a -> next;
      freeNode(a);
      a = b;
    }
  }
  free(p);
}

PathNode * buildNode(char * path) {
  PathNode * a = malloc(sizeof(PathNode));
  a -> path = malloc(sizeof(char) * strlen(path) + 1);
  strcpy(a -> path, path);
  a -> next = NULL;
  return a;
}

void freeNode(PathNode * p) {
  free(p -> path);
  free(p);
}

bool addNode(PathLL * paths, char * path) {
  //check if path has already been contained in the list
  if (containsNode(paths,path) == true){
    //fprintf(stderr,"path already contained\n");
    return false;
  } else {
    PathNode * new = buildNode(path);
    PathNode * cmpr;
    PathNode * prev = NULL;
    cmpr = paths -> head;
    while(new -> next == NULL && cmpr != NULL){
      if (strlen(cmpr -> path) < strlen(new -> path)){
	prev = cmpr;
	cmpr = cmpr -> next;
      } else if (strlen(cmpr -> path) > strlen(new -> path)){
	if (prev == NULL){
	  paths -> head = new;
	  new -> next = cmpr;
	} else {
	  prev -> next = new;
	  new -> next = cmpr;
	}
      } else {
	//check number of turns
	if (countTurn(cmpr -> path) < countTurn(new -> path)){
	  prev = cmpr;
	  cmpr = cmpr -> next;
	} else if (countTurn(cmpr -> path) > countTurn(new -> path)){
	  if (prev == NULL){
	  paths -> head = new;
	  new -> next = cmpr;
	  } else {
	  prev -> next = new;
	  new -> next = cmpr;
	  }
	} else {
	  //check alphabetical
	  if (strcmp(cmpr -> path, new -> path) < 0){
	    prev = cmpr;
	    cmpr = cmpr -> next;
	  } else {
	    if (prev == NULL){
	      paths -> head = new;
	      new -> next = cmpr;
	    } else {
	      prev -> next = new;
	      new -> next = cmpr;
	    }
	  }
	}
      }
    }
    //if new path should be behind the last one
    if (cmpr == NULL){
      if (prev == NULL){
	paths -> head = new;
      } else {
	prev -> next = new;
      }
    }
  }
  return true;
}

bool removeNode(PathLL * paths, char * path) {
  PathNode * cmpr;
  PathNode * prev = NULL;
  cmpr = paths -> head;
  while(cmpr != NULL){
    if (strcmp(cmpr -> path, path) == 0){
      if (prev == NULL){
	paths -> head = paths -> head -> next;
      } else {
	prev -> next = cmpr -> next;
      }
      freeNode(cmpr);
      return true;
    }
    prev = cmpr;
    cmpr = cmpr -> next;
  }
  fprintf(stderr, "cannot find the node with given path");
  return false;
}

bool containsNode(PathLL * paths, char * path) {
  PathNode * cmpr = paths -> head;
  while (cmpr != NULL){
    if (strcmp(cmpr -> path, path) == 0){
      return true;
    }
    cmpr = cmpr -> next;
  }
  return false;
}

void printPaths(PathLL * paths, FILE * fptr) {
	PathNode * curr = paths->head;
	int i = 0;
	while (curr != NULL) {
		fprintf(fptr, "Path %2d: %s\n", i, curr->path);
		i++;
		curr = curr->next;
	}
}

int countTurn(char * path){
  int length = 0;
  char curser = path[0];
  int turn = 0;
  while (curser != '\0'){
    length++;
    curser = path[length];
  }
  for (int i = 0; i < length; i++){
    if (path[i] != path[i + 1]){
      turn++;
    }
  }
  return turn;
}
